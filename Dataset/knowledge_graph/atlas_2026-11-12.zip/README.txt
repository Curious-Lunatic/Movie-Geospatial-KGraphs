Current atlas snapshot: 12 November 2026

Extract all files into Dataset/integrated/ in the repository (or serve this
directory with a local HTTP server). Open graph_explorer.html. Static film,
song and radius operations work locally; HTTP is needed for region-layer fetches.
The repository launcher also provides local settlement context.

There are 10,709 songs and TWO explicit source-supported song-location links.
These are railway/country reference points, not verified camera coordinates.
48 supplied song-location notes remain for review. Film locations are not
inherited by songs. Proposal JSON downloads remain proposed until source review.

See manifest.json for hashes and exact validation scope. The direct RDF
projection and sampled provenance were checked, both song claims were parsed,
queries reconciled and every song passed SongShape. Full-graph provenance
SHACL was NOT rerun. No old validation.json is included in this archive.
The separate knowledge_graph_1970_2025.zip retains its historical validation.
